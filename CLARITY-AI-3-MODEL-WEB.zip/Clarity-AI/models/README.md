# Model registry

Clarity AI supports three browser-ready ONNX models. Only the active/selected model is downloaded and loaded. All model bytes are verified against their configured SHA-256 before storage in IndexedDB or inference.

| Tier | Model ID | Size shown | Scale | Precision | Execution |
|---|---|---:|---:|---|---|
| Lite | `realesr-general-x4v3-fp32` | 4.9 MB | 4× | FP32 | WebGPU / WebGL attempt / WASM fallback |
| Balanced | `realesrgan-x4plus-fp16` | 32.2 MB | 4× | FP16 weights | WebGPU required |
| Max | `realesrgan-x4plus-fp32` | 63.9 MB | 4× | FP32 | WebGPU / WebGL attempt / WASM fallback |

Model metadata, source URLs, immutable revisions, expected SHA-256 hashes, tensor names, and device requirements are in `../js/config.js`.

## Lite — Real-ESRGAN General x4v3

- ONNX export: CoderViking/realesr-general-x4v3-onnx, commit `c6a9717`.
- Source weights: official Real-ESRGAN `realesr-general-x4v3.pth`.
- SHA-256: `1940a93ee08283a0a7286183186357b1688fe9fa8ede74604b424586aaddf112`.
- Input/output: `input` float32 NCHW RGB [0,1] → `output` [1,3,4H,4W].
- License: BSD-3-Clause.

## Balanced — Real-ESRGAN x4plus FP16

- Hugging Face: skillsafe-ai/realesrgan-x4plus, pinned revision `107475e49b7d46412cc966481efccc3500955801`.
- File: `model_fp16.onnx`.
- SHA-256: `38fe853c9cd8e1d6fd0ff387f2d43c51c1352feb9d7b3e2533d4c07b1b932f68`.
- Input/output: `input` float32 NCHW → `output` float32 [1,3,4H,4W].
- License: BSD-3-Clause.
- Runtime constraint: WebGPU.

## Max — Real-ESRGAN x4plus FP32

- Hugging Face: skillsafe-ai/realesrgan-x4plus, pinned revision `107475e49b7d46412cc966481efccc3500955801`.
- File: `model.onnx`.
- SHA-256: `4851ec156207d271f5328605d0582eeb851e656227da8aca093ced9e60789291`.
- Input/output: `input` float32 NCHW → `output` float32 [1,3,4H,4W].
- License: BSD-3-Clause.

Keep the upstream license notices with model weights if weights are ever redistributed with the site. In this project, model files are fetched from the upstream model hosts and not bundled in the ZIP.
