import { LIMITS } from './config.js';

export async function loadImageFile(file) {
  if (!(file instanceof File)) throw new Error('Please choose an image file.');
  const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
  if (!validTypes.includes(file.type)) throw new Error('Unsupported format. Please use JPG, PNG, or WebP.');
  if (file.size > LIMITS.maxUploadBytes) throw new Error('This image is larger than 25 MB. Choose a smaller file.');
  if (file.size === 0) throw new Error('The selected file is empty.');
  let bitmap;
  try { bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { throw new Error('The browser could not decode this image. The file may be damaged or unsupported.'); }
  if (!bitmap.width || !bitmap.height || bitmap.width > LIMITS.maxImageSide || bitmap.height > LIMITS.maxImageSide) {
    bitmap.close();
    throw new Error(`Image dimensions are not supported. Maximum side length is ${LIMITS.maxImageSide.toLocaleString()} px.`);
  }
  return { file, bitmap, width: bitmap.width, height: bitmap.height, type: file.type, name: file.name, size: file.size };
}

export function bitmapToCanvas(bitmap, width = bitmap.width, height = bitmap.height) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width)); canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: true });
  if (!ctx) throw new Error('Canvas is not available in this browser.');
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas;
}
