import { LIMITS } from './config.js';
import { applyEnhancements, resizeCanvas } from './enhancement.js';

export async function processImage({ bitmap, mode, factor = 2, resizeMethod = 'bicubic', adjustments, engine, signal, onProgress = () => {} }) {
  if (signal?.aborted) throw new DOMException('Processing cancelled.', 'AbortError');
  let baseCanvas;
  let effectiveInput = { width: bitmap.width, height: bitmap.height };
  let reduced = false;
  let processLabel = '';

  if (mode === 'ai') {
    if (!engine) throw new Error('The selected AI model is not loaded. Open Models to install or load the verified model first.');
    const ratio = Math.min(1, Math.sqrt(LIMITS.maxAiPixels / (bitmap.width * bitmap.height)), LIMITS.maxAiSide / Math.max(bitmap.width, bitmap.height));
    effectiveInput = { width: Math.max(1, Math.round(bitmap.width * ratio)), height: Math.max(1, Math.round(bitmap.height * ratio)) };
    reduced = ratio < 0.999;
    const inputCanvas = document.createElement('canvas');
    inputCanvas.width = effectiveInput.width; inputCanvas.height = effectiveInput.height;
    const inputContext = inputCanvas.getContext('2d', { alpha: false, willReadFrequently: true });
    if (!inputContext) throw new Error('Canvas is unavailable for AI input preparation.');
    inputContext.imageSmoothingEnabled = true; inputContext.imageSmoothingQuality = 'high';
    inputContext.drawImage(bitmap, 0, 0, inputCanvas.width, inputCanvas.height);
    const imageData = inputContext.getImageData(0, 0, inputCanvas.width, inputCanvas.height);
    onProgress({ percent: 0, message: 'Running Real-ESRGAN inference…' });
    const aiResult = await engine.upscale(imageData, inputCanvas.width, inputCanvas.height, {
      signal,
      onProgress: event => onProgress({ percent: event.percent, message: `AI inference · tile ${event.completed}/${event.total}` })
    });
    inputCanvas.width = 1; inputCanvas.height = 1;
    if (signal?.aborted) throw new DOMException('Processing cancelled.', 'AbortError');
    const upscaledCanvas = document.createElement('canvas');
    upscaledCanvas.width = aiResult.width; upscaledCanvas.height = aiResult.height;
    const outputContext = upscaledCanvas.getContext('2d', { alpha: false });
    if (!outputContext) throw new Error('Canvas is unavailable for AI output.');
    outputContext.putImageData(new ImageData(aiResult.pixels, aiResult.width, aiResult.height), 0, 0);
    if (String(factor) === '2') {
      baseCanvas = resizeCanvas(upscaledCanvas, 0.5, 'bicubic');
      upscaledCanvas.width = 1; upscaledCanvas.height = 1;
      processLabel = 'AI 4× + high-quality downscale to 2×';
    } else {
      baseCanvas = upscaledCanvas;
      processLabel = 'Native Real-ESRGAN 4× inference';
    }
  } else {
    onProgress({ percent: null, message: mode === 'standard' ? 'Resampling image…' : 'Preparing enhancement…' });
    const scale = mode === 'standard' ? Number(factor) : 1;
    const targetPixels = Math.round(bitmap.width * scale) * Math.round(bitmap.height * scale);
    if (targetPixels > LIMITS.maxStandardOutputPixels) {
      throw new Error(`This output would contain ${targetPixels.toLocaleString()} pixels, above the browser safety limit of ${LIMITS.maxStandardOutputPixels.toLocaleString()}. Choose a lower upscale factor or reduce the source image dimensions.`);
    }
    const sourceCanvas = document.createElement('canvas');
    sourceCanvas.width = bitmap.width; sourceCanvas.height = bitmap.height;
    const sourceContext = sourceCanvas.getContext('2d', { alpha: false });
    sourceContext.drawImage(bitmap, 0, 0);
    baseCanvas = resizeCanvas(sourceCanvas, scale, resizeMethod);
    sourceCanvas.width = 1; sourceCanvas.height = 1;
    processLabel = mode === 'standard' ? `Standard ${scale}× ${resizeMethod} resize (non-AI)` : 'Pixel-level enhancement (non-AI)';
  }

  if (signal?.aborted) { baseCanvas.width = 1; baseCanvas.height = 1; throw new DOMException('Processing cancelled.', 'AbortError'); }
  onProgress({ percent: null, message: 'Applying enhancement settings…' });
  const finalCanvas = applyEnhancements(baseCanvas, adjustments);
  baseCanvas.width = 1; baseCanvas.height = 1;
  onProgress({ percent: 100, message: 'Finalizing image…' });
  return {
    canvas: finalCanvas,
    inputWidth: effectiveInput.width,
    inputHeight: effectiveInput.height,
    reduced,
    processLabel,
    width: finalCanvas.width,
    height: finalCanvas.height
  };
}
