import { MODELS, DEFAULT_MODEL_ID } from './config.js';
import { downloadVerifiedModel, verifyModelBytes } from './model-downloader.js';
import { readModel, saveModel, deleteModel } from './storage.js';
import { AIEngine } from './ai-engine.js';

function initialState(model) {
  return {
    modelId: model.id,
    statusText: 'Checking local storage…',
    detail: `Checking whether ${model.name} is already installed.`,
    percent: null, installed: false, persistent: false, downloaded: false,
    verified: false, loaded: false, loading: false, downloading: false,
    indeterminate: false, downloadLabel: `Download ${model.tierLabel} model — ${model.sizeLabel}`
  };
}

export class ModelManager {
  constructor(onState = () => {}) {
    this.onState = onState;
    this.model = MODELS[DEFAULT_MODEL_ID];
    this.abortController = null;
    this.memoryBuffer = null;
    this.engine = null;
    this.state = initialState(this.model);
    this.#emit();
  }

  #set(patch) { this.state = { ...this.state, ...patch }; this.#emit(); }
  #emit() {
    this.onState({
      ...this.state,
      modelId: this.model.id,
      modelMeta: this.model,
      provider: this.engine?.provider || '',
      loaded: Boolean(this.engine?.provider)
    });
  }

  async selectModel(modelId, { autoDownload = true, autoLoad = true } = {}) {
    const nextModel = MODELS[modelId];
    if (!nextModel) throw new Error('Unknown AI model selection.');
    if (this.state.downloading || this.state.loading) throw new Error('Wait for the current model operation to finish before switching models.');
    if (nextModel.requiredProvider === 'webgpu' && !navigator.gpu) {
      if (this.model.id !== nextModel.id) {
        this.engine?.unload(); this.engine = null; this.memoryBuffer = null;
        this.model = nextModel; this.state = initialState(nextModel); this.#emit();
      }
      this.#set({ statusText: 'WebGPU unavailable', detail: `${nextModel.name} requires WebGPU. Select Lite or Max on this device.`, installed: false, verified: false, loaded: false, loading: false, downloading: false, indeterminate: false, percent: null });
      return false;
    }

    if (this.model.id !== nextModel.id) {
      this.engine?.unload();
      this.engine = null;
      this.memoryBuffer = null;
      this.model = nextModel;
      this.state = initialState(nextModel);
      this.#emit();
    }
    return this.initialize({ autoDownload, autoLoad });
  }

  async initialize({ autoDownload = true, autoLoad = true } = {}) {
    try {
      if (this.engine?.provider) return true;
      let record = null;
      let storageReadError = null;
      try { record = await readModel(this.model.id); }
      catch (error) { storageReadError = error; }

      if (!record?.bytes && !this.memoryBuffer) {
        this.#set({
          statusText: autoDownload ? `Preparing ${this.model.tierLabel} model…` : 'Not installed',
          detail: storageReadError
            ? `Persistent storage is unavailable (${storageReadError.message}). Trying a session-only model load.`
            : autoDownload
              ? `${this.model.name} is not installed. Downloading the selected model automatically.`
              : 'Download this model to enable AI super-resolution.',
          installed: false, persistent: false, downloaded: false, verified: false,
          loaded: false, percent: null, indeterminate: Boolean(autoDownload)
        });
        if (!autoDownload) return false;
        const downloaded = await this.download();
        if (!downloaded) return false;
        return autoLoad ? await this.load() : true;
      }

      if (this.memoryBuffer && !record?.bytes) {
        const hash = await verifyModelBytes(this.memoryBuffer);
        if (hash !== this.model.sha256) {
          this.memoryBuffer = null;
          throw new Error('The session copy failed SHA-256 verification. Download the model again.');
        }
        this.#set({ statusText: 'Verified · Session only', detail: 'The verified model is available in this tab. Loading the AI engine…', installed: true, persistent: false, downloaded: true, verified: true, percent: 100, indeterminate: false });
        return autoLoad ? await this.load() : true;
      }

      this.#set({
        statusText: 'Verifying saved model…',
        detail: `A local copy of ${this.model.name} was found. Checking SHA-256 before loading it.`,
        indeterminate: true, installed: true, persistent: true, downloaded: true,
        verified: false, loaded: false, percent: null
      });
      const hash = await verifyModelBytes(record.bytes);
      if (hash !== this.model.sha256) {
        await deleteModel(this.model.id);
        this.#set({ statusText: 'Stored model invalid · repairing…', detail: 'The local file failed SHA-256 verification and was removed. A clean copy will be downloaded.', installed: false, persistent: false, downloaded: false, verified: false, percent: null, indeterminate: Boolean(autoDownload) });
        if (!autoDownload) return false;
        const downloaded = await this.download();
        if (!downloaded) return false;
        return autoLoad ? await this.load() : true;
      }

      this.#set({
        statusText: 'Installed · Verified',
        detail: `${formatBytes(record.bytes.byteLength)} stored locally · SHA-256 verified. Loading the selected model…`,
        installed: true, persistent: true, downloaded: true, verified: true,
        percent: 100, indeterminate: false,
        downloadLabel: `Download ${this.model.tierLabel} model again`
      });
      return autoLoad ? await this.load() : true;
    } catch (error) {
      this.#set({ statusText: 'Model setup failed', detail: error.message || 'The selected model could not be prepared.', installed: false, verified: false, indeterminate: false, loading: false, downloading: false, percent: null, downloadLabel: 'Retry model setup' });
      const errorNode = $('#modelError');
      if (errorNode) { errorNode.textContent = error.message || String(error); errorNode.classList.remove('hidden'); }
      return false;
    }
  }

  async download() {
    if (this.state.downloading) { this.cancelDownload(); return false; }
    this.abortController = new AbortController();
    this.#set({ statusText: 'Preparing download…', detail: `Connecting to a verified source for ${this.model.name}.`, percent: null, indeterminate: true, downloading: true, downloadDisabled: false });
    $('#modelError')?.classList.add('hidden');
    try {
      const { bytes, hash, loaded, sourceUrl } = await downloadVerifiedModel({
        model: this.model,
        signal: this.abortController.signal,
        onProgress: progress => {
          const speed = Number.isFinite(progress.speed) ? `${formatRate(progress.speed)}/s` : '';
          if (progress.preparing) {
            this.#set({
              statusText: progress.fallback ? 'Switching model source…' : 'Connecting to model source…',
              detail: progress.detail || (progress.fallback ? 'The primary host did not respond. Trying the verified alternative source.' : `Preparing the ${this.model.tierLabel} model download.`),
              percent: null, speed: '', indeterminate: true
            });
            return;
          }
          this.#set({
            statusText: progress.verifying ? 'Verifying SHA-256…' : `Downloading ${this.model.tierLabel} model…`,
            detail: progress.verifying
              ? 'Download complete. Validating the model integrity before storage.'
              : `${formatBytes(progress.loaded)} downloaded${progress.total ? ` of ${formatBytes(progress.total)}` : ''}.`,
            percent: progress.verifying ? 100 : progress.percent,
            speed,
            indeterminate: !progress.verifying && progress.percent == null
          });
        }
      });
      this.#set({ statusText: 'Saving model…', detail: 'Checksum verified. Preparing the local model record.', downloaded: true, verified: true, percent: 100, indeterminate: true });
      let saved = false;
      try {
        await saveModel(bytes, { id: this.model.id, name: this.model.name, hash, revision: this.model.revision, byteLength: loaded });
        saved = true;
      } catch (storageError) {
        this.memoryBuffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
        this.#set({ detail: `Model verified but persistent browser storage is unavailable (${storageError.message}). It can be loaded for this tab only.` });
      }
      if (saved) this.memoryBuffer = null;
      const sourceHost = sourceUrl ? new URL(sourceUrl).host : 'model source';
      this.#set({
        statusText: saved ? 'Installed · Verified' : 'Verified · Session only',
        detail: saved ? `${formatBytes(loaded)} saved locally · SHA-256 ${hash.slice(0, 12)}… · source: ${sourceHost}` : `Verified model is available until this tab closes · source: ${sourceHost}.`,
        installed: true, persistent: saved, downloaded: true, verified: true,
        percent: 100, indeterminate: false, downloading: false, downloadDisabled: false,
        downloadLabel: `Download ${this.model.tierLabel} model again`
      });
      bytes.fill(0);
      return true;
    } catch (error) {
      if (error.name === 'AbortError') {
        this.#set({ statusText: 'Download cancelled', detail: 'No incomplete model was stored. You can retry when ready.', percent: null, indeterminate: false, downloading: false, downloadDisabled: false, downloadLabel: `Download ${this.model.tierLabel} model — ${this.model.sizeLabel}` });
        return false;
      }
      this.#set({ statusText: 'Download failed', detail: 'The selected model could not be installed. See the error below and retry.', percent: null, indeterminate: false, downloading: false, downloadDisabled: false, downloadLabel: 'Retry download' });
      const errorNode = $('#modelError');
      if (errorNode) { errorNode.textContent = error.message; errorNode.classList.remove('hidden'); }
      return false;
    } finally {
      this.abortController = null;
    }
  }

  cancelDownload() { this.abortController?.abort(); }

  async verify() {
    if (!this.state.installed && !this.memoryBuffer) return false;
    this.#set({ statusText: 'Verifying model…', detail: `Rechecking the ${this.model.tierLabel} model SHA-256 checksum.`, indeterminate: true, percent: null });
    try {
      let hash;
      if (this.memoryBuffer) hash = await verifyModelBytes(this.memoryBuffer);
      else {
        const record = await readModel(this.model.id);
        if (!record?.bytes) throw new Error('No model file was found in local storage.');
        hash = await verifyModelBytes(record.bytes);
      }
      if (hash !== this.model.sha256) {
        await deleteModel(this.model.id);
        this.memoryBuffer = null;
        this.unload();
        this.#set({ statusText: 'Integrity check failed', detail: 'The model failed verification and has been removed.', installed: false, persistent: false, downloaded: false, verified: false, percent: null, indeterminate: false });
        return false;
      }
      this.#set({ statusText: this.state.persistent ? 'Installed · Verified' : 'Verified · Session only', detail: `SHA-256 verified · ${hash.slice(0, 12)}…`, installed: true, downloaded: true, verified: true, percent: 100, indeterminate: false });
      return true;
    } catch (error) {
      this.#set({ statusText: 'Verification failed', detail: error.message, verified: false, indeterminate: false, percent: null });
      return false;
    }
  }

  async load() {
    if (this.state.loading) return false;
    if (this.model.requiredProvider === 'webgpu' && !navigator.gpu) {
      this.#set({ statusText: 'WebGPU unavailable', detail: `${this.model.name} requires WebGPU. Select Lite or Max on this device.`, loading: false, loaded: false, indeterminate: false });
      return false;
    }
    $('#modelError')?.classList.add('hidden');
    this.#set({ statusText: 'Loading model into ONNX Runtime…', detail: 'Starting the inference worker and selecting a supported execution provider.', loading: true, indeterminate: true, percent: null });
    try {
      let buffer = this.memoryBuffer ? this.memoryBuffer.slice(0) : null;
      if (!buffer) {
        const record = await readModel(this.model.id);
        if (!record?.bytes) throw new Error('The selected model is not installed. Download it first.');
        const hash = await verifyModelBytes(record.bytes);
        if (hash !== this.model.sha256) {
          await deleteModel(this.model.id);
          this.#set({ statusText: 'Integrity check failed', detail: 'The stored model was invalid and has been removed.', installed: false, persistent: false, downloaded: false, verified: false });
          throw new Error('The stored model failed SHA-256 verification and was removed. Download it again.');
        }
        buffer = record.bytes;
      }
      this.engine?.unload();
      this.engine = new AIEngine();
      const provider = await this.engine.load(buffer, this.model);
      if (this.state.persistent) this.memoryBuffer = null;
      this.#set({ statusText: 'Ready · Model loaded', detail: `${this.model.name} is loaded and ready for image inference.`, loading: false, loaded: true, installed: true, verified: true, provider, percent: 100, indeterminate: false });
      return true;
    } catch (error) {
      this.engine?.unload(); this.engine = null;
      this.#set({ statusText: 'Model load failed', detail: error.message, loading: false, loaded: false, indeterminate: false, percent: null });
      const errorNode = $('#modelError');
      if (errorNode) { errorNode.textContent = error.message; errorNode.classList.remove('hidden'); }
      return false;
    }
  }

  unload() {
    this.engine?.unload(); this.engine = null;
    this.#set({ statusText: this.state.verified ? (this.state.persistent ? 'Installed · Verified' : 'Verified · Session only') : 'Not installed', detail: this.state.verified ? 'The model remains saved locally, but is no longer loaded in memory.' : 'Select Download to install this model.', loaded: false, provider: '', loading: false, indeterminate: false });
  }

  async remove() {
    this.unload();
    await deleteModel(this.model.id);
    this.memoryBuffer = null;
    this.#set({ statusText: 'Not installed', detail: `${this.model.name} has been deleted from this browser. Other installed models are untouched.`, installed: false, persistent: false, downloaded: false, verified: false, loaded: false, percent: null, downloadLabel: `Download ${this.model.tierLabel} model — ${this.model.sizeLabel}` });
  }

  get engineInstance() { return this.engine; }
  get modelConfig() { return this.model; }
}

function $(selector) { return document.querySelector(selector); }
function formatBytes(value) { if (value < 1024) return `${value} B`; return `${(value / 1024 / 1024).toFixed(1)} MB`; }
function formatRate(value) { return value > 1024 * 1024 ? `${(value / 1024 / 1024).toFixed(1)} MB` : `${Math.round(value / 1024)} KB`; }
