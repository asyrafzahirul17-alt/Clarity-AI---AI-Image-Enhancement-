let toastTimer = 0;

export function $(selector, root = document) { return root.querySelector(selector); }
export function $$(selector, root = document) { return [...root.querySelectorAll(selector)]; }

export function notify(message, type = 'success', duration = 3600) {
  const region = $('#toastRegion');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = document.createElement('span');
  icon.className = 'toast-icon';
  icon.textContent = type === 'error' ? '!' : type === 'warning' ? '⚠' : '✓';
  const text = document.createElement('span');
  text.textContent = message;
  toast.append(icon, text);
  region.append(toast);
  window.setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(6px)';
    window.setTimeout(() => toast.remove(), 220);
  }, duration);
}

export function setView(name) {
  $$('.view').forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
  $$('.nav-link').forEach(button => button.classList.toggle('active', button.dataset.view === name));
  document.querySelector('.main-content')?.scrollTo({ top: 0, behavior: 'smooth' });
  history.replaceState(null, '', `#${name}`);
}

export function setTheme(theme) {
  document.body.classList.toggle('theme-light', theme === 'light');
  document.body.classList.toggle('theme-dark', theme !== 'light');
  const meta = $('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'light' ? '#f1f3f1' : '#101216';
  const toggle = $('#themeToggle');
  if (toggle) toggle.setAttribute('aria-label', theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme');
}

export function setBusy(isBusy, message = 'Processing…') {
  const state = $('#processingState');
  state.classList.toggle('busy', isBusy);
  state.classList.remove('error');
  $('#processingState .state-indicator').style.background = '';
  $('#processingMessage').textContent = message;
  $('#processButton').disabled = isBusy;
  $('#cancelProcess').classList.toggle('hidden', !isBusy);
  if (!isBusy) $('#progressTrack').classList.add('hidden');
}

export function setProgress(percent, message) {
  const track = $('#progressTrack');
  track.classList.remove('hidden');
  $('#progressFill').style.width = percent == null ? '28%' : `${Math.max(0, Math.min(100, percent))}%`;
  $('#progressFill').classList.toggle('indeterminate', percent == null);
  if (message) $('#processingMessage').textContent = message;
}

export function setProcessingError(message) {
  $('#processingState').classList.remove('busy');
  $('#processingState').classList.add('error');
  $('#processingMessage').textContent = message;
  $('#processButton').disabled = false;
  $('#cancelProcess').classList.add('hidden');
}

export function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB'];
  let value = bytes / 1024, index = 0;
  while (value >= 1024 && index < units.length - 1) { value /= 1024; index++; }
  return `${value.toFixed(value >= 100 ? 0 : 1)} ${units[index]}`;
}

export function formatDimensions(width, height) { return `${width.toLocaleString()} × ${height.toLocaleString()}`; }
export function safeFileName(name) { return String(name || 'image').replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]+/g, '-').slice(0, 80) || 'image'; }

export function updateProviderAvailability() {
  const gpu = Boolean(navigator.gpu);
  const canvas = document.createElement('canvas');
  let gl = false;
  try { gl = Boolean(canvas.getContext('webgl2') || canvas.getContext('webgl')); } catch { gl = false; }
  const gpuNode = $('#providerWebGPU');
  const glNode = $('#providerWebGL');
  gpuNode.textContent = gpu ? 'Available' : 'Unavailable';
  gpuNode.className = `provider-state ${gpu ? 'supported' : 'unavailable'}`;
  glNode.textContent = gl ? 'Available' : 'Unavailable';
  glNode.className = `provider-state ${gl ? 'supported' : 'unavailable'}`;
  return { webgpu: gpu, webgl: gl };
}

export function renderHistory(items, onOpen, onDelete) {
  const list = $('#historyList');
  $('#historyCount').textContent = `${items.length} ITEM${items.length === 1 ? '' : 'S'}`;
  list.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = '<span class="empty-state-icon">◷</span><h3>No history yet</h3><p>Completed enhancements will show up here.</p><button class="text-button" data-view="enhance" type="button">Go to workspace →</button>';
    empty.querySelector('[data-view]').addEventListener('click', () => setView('enhance'));
    list.append(empty);
    return;
  }
  for (const item of items) {
    const row = document.createElement('article');
    row.className = 'history-item';
    let thumb;
    if (item.thumbnail) {
      thumb = document.createElement('img'); thumb.className = 'history-thumb'; thumb.src = item.thumbnail; thumb.alt = '';
    } else {
      thumb = document.createElement('div'); thumb.className = 'history-thumb history-placeholder'; thumb.textContent = '✦';
    }
    const info = document.createElement('div'); info.className = 'history-info';
    const title = document.createElement('strong'); title.textContent = item.fileName || 'Untitled image';
    const meta = document.createElement('small');
    const date = new Date(item.createdAt).toLocaleString();
    meta.textContent = `${item.modeLabel} · ${item.factorLabel} · ${item.outputDimensions} · ${date}`;
    info.append(title, meta);
    const actions = document.createElement('div'); actions.className = 'history-actions';
    const open = document.createElement('button'); open.type = 'button'; open.className = 'history-action'; open.textContent = 'Open result'; open.disabled = !item.resultBlob; open.title = item.resultBlob ? 'Open saved result' : 'Enable result storage in Settings to reopen files'; open.addEventListener('click', () => onOpen(item));
    const del = document.createElement('button'); del.type = 'button'; del.className = 'history-action delete'; del.textContent = 'Delete'; del.addEventListener('click', () => onDelete(item.id));
    actions.append(open, del); row.append(thumb, info, actions); list.append(row);
  }
}

export function setModelUI(state) {
  const meta = state.modelMeta || {};
  const status = $('#modelStatusText');
  if (status) {
    if (!String(state.statusText || '').startsWith('Checking local storage')) status.classList.remove('skeleton-text');
    status.textContent = state.statusText || 'Model not installed';
  }
  const text = (selector, value) => { const node = $(selector); if (node && value != null) node.textContent = value; };
  text('#modelPercent', state.percent == null ? '—' : `${Math.round(state.percent)}%`);
  text('#modelDownloadDetail', state.detail || '');
  text('#modelSpeed', state.speed || '');
  text('#modelNameTitle', meta.name || 'AI model');
  text('#modelDescription', meta.description || '');
  text('#modelLicense', meta.license || '—');
  text('#modelFormat', meta.format || 'ONNX');
  text('#modelSizeValue', meta.sizeLabel || '—');
  text('#modelScaleValue', `${meta.scale || 4}× native`);
  text('#modelPrecisionValue', meta.precision || '—');
  text('#modelRevisionValue', meta.shortRevision || '—');
  text('#miniModelName', meta.name || 'AI model');
  text('#miniModelStatus', state.loaded ? `Ready · ${state.provider || 'loaded'}` : state.verified ? (state.persistent ? 'Verified · Installed' : 'Verified · Session only') : state.loading ? 'Loading into memory…' : state.downloading ? 'Downloading model…' : 'Not installed');
  text('#activeProvider', state.loaded ? state.provider : 'Not loaded');
  text('#engineLabel', state.loaded ? `${meta.tierLabel || 'AI'} engine ready · ${state.provider}` : state.verified ? 'Model installed · not loaded' : 'AI engine not loaded');

  const fill = $('#modelProgressFill');
  if (fill) {
    fill.style.width = state.percent == null ? (state.indeterminate ? '28%' : '0%') : `${Math.max(0, Math.min(100, state.percent))}%`;
    fill.classList.toggle('indeterminate', Boolean(state.indeterminate));
  }
  const downloadText = $('#downloadModelText');
  if (downloadText) downloadText.textContent = state.downloading ? 'Cancel download' : state.downloadLabel || `Download ${meta.tierLabel || ''} model`;
  const downloadButton = $('#downloadModelButton');
  if (downloadButton) downloadButton.disabled = Boolean(state.downloadDisabled || state.loading);
  const loadButton = $('#loadModelButton');
  if (loadButton) {
    loadButton.disabled = (!state.verified && !state.loaded) || state.loading || state.downloading;
    loadButton.textContent = state.loading ? 'Loading…' : state.loaded ? 'Unload model' : 'Load model';
  }
  const verifyButton = $('#verifyModelButton');
  if (verifyButton) verifyButton.disabled = (!state.installed && !state.verified) || state.downloading || state.loading;
  const deleteButton = $('#deleteModelButton');
  if (deleteButton) deleteButton.disabled = !state.installed || state.downloading || state.loading;

  const providerNote = meta.requiredProvider === 'webgpu'
    ? (navigator.gpu ? 'WebGPU required · available on this browser.' : 'WebGPU required · unavailable on this browser. Choose Lite or Max.')
    : `${meta.bestFor || 'General image restoration'} · ${meta.scale || 4}× output.`;
  const note = $('#modelChoiceHint');
  if (note) note.textContent = providerNote;

  const select = $('#aiModelSelect');
  if (select && state.modelId && select.value !== state.modelId) select.value = state.modelId;
  const sourceLink = $('#modelSourceLink');
  if (sourceLink && meta.sourceUrl) { sourceLink.href = meta.sourceUrl; sourceLink.textContent = `${meta.sourceLabel || 'View model source'} ↗`; }
  const chip = $('#engineChip');
  if (chip) chip.classList.toggle('ready', state.loaded);

  document.querySelectorAll('[data-model-select]').forEach(button => {
    const selected = button.dataset.modelSelect === state.modelId;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
    button.disabled = Boolean(state.loading || state.downloading);
  });
  document.querySelectorAll('[data-model-state]').forEach(node => {
    const selected = node.dataset.modelState === state.modelId;
    if (selected) {
      node.textContent = state.loaded ? 'ACTIVE · READY' : state.installed ? 'INSTALLED' : state.downloading ? 'DOWNLOADING' : state.loading ? 'LOADING' : state.statusText === 'WebGPU unavailable' ? 'NEEDS WEBGPU' : 'SELECTED';
      node.classList.toggle('is-installed', Boolean(state.installed || state.loaded));
    } else {
      node.textContent = 'AVAILABLE';
      node.classList.remove('is-installed');
    }
  });
}
