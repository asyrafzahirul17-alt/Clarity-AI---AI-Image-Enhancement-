// Model registry for Clarity AI. The app downloads only the selected model.
export const MODELS = Object.freeze({
  'realesr-general-x4v3-fp32': Object.freeze({
    id: 'realesr-general-x4v3-fp32',
    tier: 'LIGHT',
    tierLabel: 'Lite',
    name: 'Real-ESRGAN General x4v3',
    displayName: 'Lite · General x4v3',
    description: 'The smallest general-purpose model for everyday photos, screenshots, illustrations, and compressed images. Best starting point for phones and modest computers.',
    bestFor: 'Everyday photos · lower-end devices',
    url: 'https://huggingface.co/CoderViking/realesr-general-x4v3-onnx/resolve/c6a9717/realesr-general-x4v3.onnx',
    fallbackUrls: ['https://www.webkitonline.com/models/CoderViking/realesr-general-x4v3-onnx/realesr-general-x4v3.onnx'],
    revision: 'c6a9717',
    shortRevision: 'c6a9717',
    expectedBytes: 4866417,
    sha256: '1940a93ee08283a0a7286183186357b1688fe9fa8ede74604b424586aaddf112',
    inputName: 'input',
    outputName: 'output',
    scale: 4,
    tileSize: 128,
    precision: 'FP32',
    format: 'ONNX · FP32',
    sizeLabel: '4.9 MB',
    license: 'BSD-3-Clause',
    requiredProvider: null,
    sourceUrl: 'https://huggingface.co/CoderViking/realesr-general-x4v3-onnx',
    sourceLabel: 'View model source'
  }),
  'realesrgan-x4plus-fp16': Object.freeze({
    id: 'realesrgan-x4plus-fp16',
    tier: 'BALANCED',
    tierLabel: 'Balanced',
    name: 'Real-ESRGAN x4plus FP16',
    displayName: 'Balanced · x4plus FP16',
    description: 'A half-precision version of the larger x4plus network. A good middle option when the device supports WebGPU and you want a stronger restoration model with a smaller download than FP32.',
    bestFor: 'WebGPU devices · balanced quality and size',
    url: 'https://huggingface.co/skillsafe-ai/realesrgan-x4plus/resolve/107475e49b7d46412cc966481efccc3500955801/model_fp16.onnx',
    fallbackUrls: ['https://models.skillsafe.ai/realesrgan-x4plus-fp16@v0.1.0/model_fp16.onnx'],
    revision: '107475e49b7d46412cc966481efccc3500955801',
    shortRevision: '107475e49b7d',
    expectedBytes: 32.19 * 1024 * 1024,
    sha256: '38fe853c9cd8e1d6fd0ff387f2d43c51c1352feb9d7b3e2533d4c07b1b932f68',
    inputName: 'input',
    outputName: 'output',
    scale: 4,
    tileSize: 96,
    precision: 'FP16 weights',
    format: 'ONNX · FP16',
    sizeLabel: '32.2 MB',
    license: 'BSD-3-Clause',
    requiredProvider: 'webgpu',
    sourceUrl: 'https://huggingface.co/skillsafe-ai/realesrgan-x4plus',
    sourceLabel: 'View model source'
  }),
  'realesrgan-x4plus-fp32': Object.freeze({
    id: 'realesrgan-x4plus-fp32',
    tier: 'MAX',
    tierLabel: 'Max',
    name: 'Real-ESRGAN x4plus FP32',
    displayName: 'Max · x4plus FP32',
    description: 'The full-precision x4plus network for detailed restoration and maximum fidelity in this model lineup. It has the largest download and needs more memory and processing time.',
    bestFor: 'Desktop · detailed photo restoration',
    url: 'https://huggingface.co/skillsafe-ai/realesrgan-x4plus/resolve/107475e49b7d46412cc966481efccc3500955801/model.onnx',
    fallbackUrls: ['https://models.skillsafe.ai/realesrgan-x4plus-fp32@v0.1.0/model.onnx'],
    revision: '107475e49b7d46412cc966481efccc3500955801',
    shortRevision: '107475e49b7d',
    expectedBytes: 63.95 * 1024 * 1024,
    sha256: '4851ec156207d271f5328605d0582eeb851e656227da8aca093ced9e60789291',
    inputName: 'input',
    outputName: 'output',
    scale: 4,
    tileSize: 96,
    precision: 'FP32',
    format: 'ONNX · FP32',
    sizeLabel: '63.9 MB',
    license: 'BSD-3-Clause',
    requiredProvider: null,
    sourceUrl: 'https://huggingface.co/skillsafe-ai/realesrgan-x4plus',
    sourceLabel: 'View model source'
  })
});

// Lite is the default so first-time visitors do not automatically download a large model.
export const DEFAULT_MODEL_ID = 'realesr-general-x4v3-fp32';
export const MODEL = MODELS[DEFAULT_MODEL_ID]; // Backward-compatible alias for older modules.

export const RUNTIME = Object.freeze({
  version: '1.31.1',
  moduleUrls: {
    webgpu: 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/ort.webgpu.min.mjs',
    webgl: 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/ort.webgl.min.mjs',
    wasm: 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/ort.wasm.min.mjs'
  },
  wasmBaseUrl: 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/'
});

export const LIMITS = Object.freeze({
  maxUploadBytes: 25 * 1024 * 1024,
  maxImageSide: 12000,
  maxAiPixels: 450000,
  maxAiSide: 1280,
  maxStandardOutputPixels: 8000000,
  aiTileSize: 128,
  aiTilePadding: 16
});

export const DEFAULT_SETTINGS = Object.freeze({
  theme: 'dark',
  defaultMode: 'ai',
  defaultFactor: '2',
  defaultFormat: 'image/png',
  defaultQuality: 92,
  aiModelId: DEFAULT_MODEL_ID,
  reducedMotion: false,
  saveHistoryResults: false,
  saveHistoryThumbnails: false
});

export const PRESETS = Object.freeze({
  natural: { brightness: 0, contrast: 0, saturation: 0, sharpness: 20, noiseReduction: 0 },
  balanced: { brightness: 0, contrast: 8, saturation: 8, sharpness: 36, noiseReduction: 10 },
  sharp: { brightness: 0, contrast: 12, saturation: 0, sharpness: 72, noiseReduction: 0 },
  soft: { brightness: 3, contrast: -5, saturation: -10, sharpness: 8, noiseReduction: 24 },
  detail: { brightness: 0, contrast: 18, saturation: 8, sharpness: 65, noiseReduction: 5 }
});

export const ADJUSTMENT_KEYS = Object.freeze(['brightness', 'contrast', 'saturation', 'sharpness', 'noiseReduction']);
