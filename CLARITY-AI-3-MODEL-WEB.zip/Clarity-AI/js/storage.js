const DB_NAME = 'clarity-ai-local';
const DB_VERSION = 1;
let dbPromise;

function openDatabase() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not available in this browser. Persistent model storage is unavailable.'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('models')) db.createObjectStore('models', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' });
      if (!db.objectStoreNames.contains('history')) {
        const history = db.createObjectStore('history', { keyPath: 'id', autoIncrement: true });
        history.createIndex('createdAt', 'createdAt');
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open local storage.'));
    request.onblocked = () => reject(new Error('Local storage is blocked by another Clarity AI tab. Close the other tab and retry.'));
  });
  return dbPromise;
}

async function transaction(storeName, mode, action) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    let request;
    try { request = action(store); } catch (error) { reject(error); return; }
    if (request) {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Local storage operation failed.'));
    }
    tx.onabort = () => reject(tx.error || new Error('Local storage transaction was aborted.'));
    tx.onerror = () => reject(tx.error || new Error('Local storage transaction failed.'));
    if (!request) tx.oncomplete = () => resolve(true);
  });
}

export async function saveModel(bytes, metadata) {
  const buffer = bytes instanceof ArrayBuffer ? bytes : (bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength ? bytes.buffer : bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
  await transaction('models', 'readwrite', store => store.put({ id: metadata.id, bytes: buffer, ...metadata, savedAt: Date.now() }));
}
export async function readModel(id) { return transaction('models', 'readonly', store => store.get(id)); }
export async function deleteModel(id) { return transaction('models', 'readwrite', store => store.delete(id)); }
export async function getSetting(key) { const record = await transaction('settings', 'readonly', store => store.get(key)); return record?.value; }
export async function saveSetting(key, value) { return transaction('settings', 'readwrite', store => store.put({ key, value })); }
export async function getAllSettings() {
  const records = await transaction('settings', 'readonly', store => store.getAll());
  return Object.fromEntries((records || []).map(item => [item.key, item.value]));
}
export async function addHistory(record) { return transaction('history', 'readwrite', store => store.add(record)); }
export async function getHistory() {
  const rows = await transaction('history', 'readonly', store => store.getAll());
  return (rows || []).sort((a, b) => b.createdAt - a.createdAt);
}
export async function deleteHistoryItem(id) { return transaction('history', 'readwrite', store => store.delete(Number(id))); }
export async function clearHistory() { return transaction('history', 'readwrite', store => store.clear()); }
export async function getStorageEstimate() {
  if (navigator.storage?.estimate) return navigator.storage.estimate();
  return null;
}
