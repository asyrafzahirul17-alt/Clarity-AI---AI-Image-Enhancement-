import { RUNTIME, LIMITS } from './config.js';

let ortModule;
let session;
let activeProvider = 'Unknown';
let modelSpec = null;
let inputTensorName = 'input';
let outputTensorName = 'output';
const cancelledJobs = new Set();

async function initialize(buffer, config = {}) {
  modelSpec = { scale: 4, tileSize: LIMITS.aiTileSize, ...config };
  const candidates = [];
  if (modelSpec.requiredProvider) {
    if (modelSpec.requiredProvider === 'webgpu' && !(typeof navigator !== 'undefined' && navigator.gpu)) {
      throw new Error(`${modelSpec.name || 'This model'} requires WebGPU, but this browser does not expose it.`);
    }
    candidates.push(modelSpec.requiredProvider);
  } else {
    if (typeof navigator !== 'undefined' && navigator.gpu) candidates.push('webgpu');
    if (typeof OffscreenCanvas !== 'undefined') candidates.push('webgl');
    candidates.push('wasm');
  }

  const errors = [];
  for (const provider of candidates) {
    try {
      ortModule = await import(RUNTIME.moduleUrls[provider]);
      if (ortModule.env?.wasm) {
        ortModule.env.wasm.wasmPaths = RUNTIME.wasmBaseUrl;
        ortModule.env.wasm.numThreads = 1;
        ortModule.env.wasm.proxy = false;
      }
      const executionProviders = modelSpec.requiredProvider ? [provider] : (provider === 'wasm' ? ['wasm'] : [provider, 'wasm']);
      session = await ortModule.InferenceSession.create(new Uint8Array(buffer), {
        executionProviders,
        graphOptimizationLevel: 'all',
        executionMode: 'sequential',
        intraOpNumThreads: 1
      });
      inputTensorName = modelSpec.inputName || session.inputNames[0];
      outputTensorName = modelSpec.outputName || session.outputNames[0];
      if (!session.inputNames.includes(inputTensorName)) throw new Error(`Model input tensor "${inputTensorName}" was not found. Available: ${session.inputNames.join(', ')}`);
      if (!session.outputNames.includes(outputTensorName)) throw new Error(`Model output tensor "${outputTensorName}" was not found. Available: ${session.outputNames.join(', ')}`);
      activeProvider = provider.toUpperCase();
      return activeProvider;
    } catch (error) {
      errors.push(`${provider}: ${error?.message || error}`);
      try { await session?.release?.(); } catch { /* ignore failed provider cleanup */ }
      session = undefined;
      ortModule = undefined;
      if (modelSpec.requiredProvider) break;
    }
  }
  throw new Error(`ONNX Runtime could not initialize ${modelSpec.name || 'this model'}. ${errors.join(' | ')}`);
}

function makeInputTensor(source, imageWidth, imageHeight, left, top, width, height) {
  const planeSize = width * height;
  const values = new Float32Array(planeSize * 3);
  for (let y = 0; y < height; y++) {
    const sourceRow = ((top + y) * imageWidth + left) * 4;
    const planeRow = y * width;
    for (let x = 0; x < width; x++) {
      const sourceIndex = sourceRow + x * 4;
      const targetIndex = planeRow + x;
      values[targetIndex] = source[sourceIndex] / 255;
      values[planeSize + targetIndex] = source[sourceIndex + 1] / 255;
      values[planeSize * 2 + targetIndex] = source[sourceIndex + 2] / 255;
    }
  }
  return new ortModule.Tensor('float32', values, [1, 3, height, width]);
}

async function upscale(jobId, sourcePixels, imageWidth, imageHeight, options) {
  if (!session || !modelSpec) throw new Error('The selected AI model is not loaded.');
  if (imageWidth * imageHeight > LIMITS.maxAiPixels) throw new Error('Image exceeds the AI memory safety limit. Reduce its input resolution and retry.');
  const scale = Number(modelSpec.scale) || 4;
  const outputWidth = imageWidth * scale;
  const outputHeight = imageHeight * scale;
  const output = new Uint8ClampedArray(outputWidth * outputHeight * 4);
  const tileSize = options.tileSize || modelSpec.tileSize || LIMITS.aiTileSize;
  const padding = options.padding ?? LIMITS.aiTilePadding;
  const columns = Math.ceil(imageWidth / tileSize);
  const rows = Math.ceil(imageHeight / tileSize);
  const totalTiles = columns * rows;
  let completed = 0;

  for (let top = 0; top < imageHeight; top += tileSize) {
    for (let left = 0; left < imageWidth; left += tileSize) {
      if (cancelledJobs.has(jobId)) {
        cancelledJobs.delete(jobId);
        const error = new Error('Processing cancelled.'); error.name = 'AbortError'; throw error;
      }
      const right = Math.min(imageWidth, left + tileSize);
      const bottom = Math.min(imageHeight, top + tileSize);
      const patchLeft = Math.max(0, left - padding);
      const patchTop = Math.max(0, top - padding);
      const patchRight = Math.min(imageWidth, right + padding);
      const patchBottom = Math.min(imageHeight, bottom + padding);
      const patchWidth = patchRight - patchLeft;
      const patchHeight = patchBottom - patchTop;
      const inputTensor = makeInputTensor(sourcePixels, imageWidth, imageHeight, patchLeft, patchTop, patchWidth, patchHeight);
      let outputs;
      try {
        outputs = await session.run({ [inputTensorName]: inputTensor });
        const result = outputs[outputTensorName];
        if (!result || result.dims.length !== 4 || result.dims[1] !== 3) throw new Error('Unexpected ONNX output tensor. Expected [1, 3, scaled height, scaled width].');
        const data = result.data;
        const resultWidth = result.dims[3];
        const resultHeight = result.dims[2];
        if (resultWidth !== patchWidth * scale || resultHeight !== patchHeight * scale) throw new Error(`The selected model returned ${resultWidth}×${resultHeight}; expected ${patchWidth * scale}×${patchHeight * scale}.`);
        const cropLeft = (left - patchLeft) * scale;
        const cropTop = (top - patchTop) * scale;
        const coreWidth = (right - left) * scale;
        const coreHeight = (bottom - top) * scale;
        for (let y = 0; y < coreHeight; y++) {
          const sourceY = cropTop + y;
          const targetY = top * scale + y;
          const sourceBase = sourceY * resultWidth;
          const targetBase = targetY * outputWidth + left * scale;
          for (let x = 0; x < coreWidth; x++) {
            const src = sourceBase + cropLeft + x;
            const dst = (targetBase + x) * 4;
            output[dst] = clampByte(data[src] * 255);
            output[dst + 1] = clampByte(data[resultWidth * resultHeight + src] * 255);
            output[dst + 2] = clampByte(data[resultWidth * resultHeight * 2 + src] * 255);
            output[dst + 3] = 255;
          }
        }
      } finally {
        inputTensor.dispose?.();
        if (outputs) Object.values(outputs).forEach(tensor => tensor?.dispose?.());
      }
      completed++;
      self.postMessage({ type: 'progress', jobId, completed, total: totalTiles, percent: completed / totalTiles * 100, provider: activeProvider, modelName: modelSpec.name });
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
  cancelledJobs.delete(jobId);
  self.postMessage({ type: 'result', jobId, width: outputWidth, height: outputHeight, pixels: output.buffer }, [output.buffer]);
}

function clampByte(value) { return Math.max(0, Math.min(255, Math.round(value))); }

self.addEventListener('message', async event => {
  const message = event.data || {};
  if (message.type === 'cancel') { cancelledJobs.add(message.jobId); return; }
  if (message.type === 'init') {
    try {
      const provider = await initialize(message.buffer, message.modelConfig || {});
      self.postMessage({ type: 'ready', requestId: message.requestId, provider, modelName: modelSpec?.name || '' });
    } catch (error) {
      self.postMessage({ type: 'error', requestId: message.requestId, message: error?.message || String(error) });
    }
  }
  if (message.type === 'upscale') {
    try {
      await upscale(message.jobId, new Uint8ClampedArray(message.pixels), message.width, message.height, message.options || {});
    } catch (error) {
      self.postMessage({ type: 'error', jobId: message.jobId, message: error?.message || String(error), name: error?.name || 'Error' });
    }
  }
  if (message.type === 'dispose') {
    try { await session?.release?.(); } catch { /* no-op */ }
    session = undefined;
    modelSpec = null;
    self.close();
  }
});
