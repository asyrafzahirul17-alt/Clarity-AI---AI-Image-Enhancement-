import { MODELS, DEFAULT_MODEL_ID, DEFAULT_SETTINGS, PRESETS, ADJUSTMENT_KEYS } from './config.js';
import { ModelManager } from './model-manager.js';
import { loadImageFile } from './image-loader.js';
import { processImage } from './image-processor.js';
import { canvasToBlob, downloadBlob, mimeExtension } from './export.js';
import {
  $, $$, notify, setView, setTheme, setBusy, setProgress, setProcessingError,
  formatBytes, formatDimensions, safeFileName, updateProviderAvailability,
  renderHistory, setModelUI
} from './ui.js';
import {
  getAllSettings, saveSetting, addHistory, getHistory, deleteHistoryItem,
  clearHistory as clearStoredHistory, getStorageEstimate
} from './storage.js';

let settings = { ...DEFAULT_SETTINGS };
let currentImage = null;
let originalUrl = null;
let resultUrl = null;
let resultCanvas = null;
let resultBlob = null;
let processController = null;
let zoom = 1;
let compare = 50;
let currentHistory = [];
const modelManager = new ModelManager(setModelUI);

function adjustmentsFromUI() {
  return Object.fromEntries(ADJUSTMENT_KEYS.map(key => [key, Number($(`#${key}`).value)]));
}

async function persistSetting(key, value) {
  settings[key] = value;
  try { await saveSetting(key, value); }
  catch {
    try { localStorage.setItem(`clarity.${key}`, JSON.stringify(value)); }
    catch { notify('This browser could not persist the setting. It will reset when you close the tab.', 'warning'); }
  }
}

async function loadSettings() {
  try { settings = { ...DEFAULT_SETTINGS, ...(await getAllSettings()) }; }
  catch {
    const local = {};
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      try { const value = localStorage.getItem(`clarity.${key}`); if (value !== null) local[key] = JSON.parse(value); } catch { /* ignore invalid local preference */ }
    }
    settings = { ...DEFAULT_SETTINGS, ...local };
  }
  setTheme(settings.theme);
  document.body.classList.toggle('reduced-motion', Boolean(settings.reducedMotion));
  $('#settingTheme').value = settings.theme;
  $('#reducedMotion').checked = Boolean(settings.reducedMotion);
  if (!MODELS[settings.aiModelId]) settings.aiModelId = DEFAULT_MODEL_ID;
  $('#aiModelSelect').value = settings.aiModelId;
  $('#defaultMode').value = settings.defaultMode;
  $('#defaultFactor').value = settings.defaultFactor;
  $('#defaultFormat').value = settings.defaultFormat;
  $('#defaultQuality').value = settings.defaultQuality;
  $('#defaultQualityValue').textContent = `${settings.defaultQuality}%`;
  $('#saveHistoryResults').checked = Boolean(settings.saveHistoryResults);
  $('#saveHistoryThumbnails').checked = Boolean(settings.saveHistoryThumbnails);
  $('#processingMode').value = settings.defaultMode;
  $('#outputFormat').value = settings.defaultFormat;
  $('#imageQuality').value = settings.defaultQuality;
  $('#qualityValue').textContent = `${settings.defaultQuality}%`;
  selectFactor(settings.defaultFactor);
  updateModeControls();
}

function selectFactor(value) {
  const factor = String(value) === '4' ? '4' : '2';
  $$('[data-factor]').forEach(button => button.classList.toggle('selected', button.dataset.factor === factor));
  settings.defaultFactor = factor;
}

async function activateModel(modelId, { silent = false } = {}) {
  const model = MODELS[modelId];
  if (!model) { notify('That AI model is not available in this build.', 'error'); return false; }
  if (processController) {
    notify('Finish or cancel the current image process before changing AI models.', 'warning');
    $('#aiModelSelect').value = modelManager.modelConfig.id;
    return false;
  }
  if (model.requiredProvider === 'webgpu' && !navigator.gpu) {
    notify(`${model.name} needs WebGPU. This browser does not expose WebGPU; choose Lite or Max instead.`, 'warning', 6000);
    $('#aiModelSelect').value = modelManager.modelConfig.id;
    setView('models');
    return false;
  }
  if (modelManager.state.loading || modelManager.state.downloading) {
    notify('Wait until the current model operation finishes before switching.', 'warning');
    $('#aiModelSelect').value = modelManager.modelConfig.id;
    return false;
  }
  $('#aiModelSelect').value = modelId;
  await persistSetting('aiModelId', modelId);
  const ok = await modelManager.selectModel(modelId, { autoDownload: true, autoLoad: true });
  updateModeControls();
  if (!silent) {
    if (ok) notify(`${model.displayName} is ready · ${modelManager.engineInstance?.provider || 'AI engine loaded'}.`, 'success', 4600);
    else notify(`${model.displayName} could not be prepared. Check the model status for details.`, 'error', 6000);
  }
  return ok;
}

function updateModeControls() {
  const mode = $('#processingMode').value;
  $('#aiControls').classList.toggle('hidden', mode !== 'ai');
  $('#standardControls').classList.toggle('hidden', mode !== 'standard');
  const notes = {
    ai: `<span class="note-icon">✦</span><span>Neural super-resolution · ${modelManager.modelConfig.displayName}. Select Lite, Balanced, or Max to match your device.</span>`,
    standard: '<span class="note-icon">⌁</span><span>Conventional browser resizing. This mode does not use AI.</span>',
    enhance: '<span class="note-icon">◌</span><span>Adjust tone, color, sharpness, and noise without upscaling.</span>'
  };
  $('#modeNote').innerHTML = notes[mode];
  $('#processButtonText').textContent = mode === 'ai' ? 'AI enhance image' : mode === 'standard' ? 'Upscale image' : 'Apply enhancements';
}

function updateCompare(value = compare) {
  compare = Math.max(0, Math.min(100, Number(value) || 0));
  $('#afterLayer').style.clipPath = `inset(0 0 0 ${compare}%)`;
  $('#compareDivider').style.left = `${compare}%`;
  $('#compareRange').value = compare;
  $('#compareRange').setAttribute('aria-valuetext', `${compare}% original, ${100 - compare}% enhanced`);
  $('#compareValue').textContent = `${compare}%`;
}

function updateCompareFromPointer(event) {
  const stage = $('#compareStage');
  const rect = stage.getBoundingClientRect();
  if (!rect.width) return;
  updateCompare(((event.clientX - rect.left) / rect.width) * 100);
}

function bindButtonAnimations() {
  const timers = new WeakMap();
  document.addEventListener('pointerdown', event => {
    const button = event.target.closest('button:not(:disabled)');
    if (!button) return;
    const rect = button.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'button-ripple';
    ripple.style.left = `${event.clientX - rect.left}px`;
    ripple.style.top = `${event.clientY - rect.top}px`;
    button.classList.add('ripple-ready');
    button.append(ripple);
    ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
  }, true);

  document.addEventListener('click', event => {
    const button = event.target.closest('button:not(:disabled)');
    if (!button) return;
    button.classList.remove('button-clicked');
    // Restart the short feedback animation even when the same button is clicked repeatedly.
    void button.offsetWidth;
    button.classList.add('button-clicked');
    window.clearTimeout(timers.get(button));
    timers.set(button, window.setTimeout(() => button.classList.remove('button-clicked'), 380));
  }, true);
}

function setZoom(value) {
  zoom = Math.min(2.5, Math.max(0.5, value));
  $('#compareStage').style.setProperty('--zoom', zoom);
  $('#zoomValue').textContent = `${Math.round(zoom * 100)}%`;
}

function releaseCurrentImage() {
  if (currentImage?.bitmap) currentImage.bitmap.close();
  currentImage = null;
  if (originalUrl) URL.revokeObjectURL(originalUrl);
  if (resultUrl) URL.revokeObjectURL(resultUrl);
  originalUrl = null; resultUrl = null; resultCanvas = null; resultBlob = null;
}

async function acceptImageFile(file) {
  try {
    const loaded = await loadImageFile(file);
    releaseCurrentImage();
    currentImage = loaded;
    originalUrl = URL.createObjectURL(file);
    $('#beforeImage').src = originalUrl;
    $('#afterImage').removeAttribute('src');
    $('#afterImage').classList.add('hidden');
    $('#emptyResultHint').classList.remove('hidden');
    $('#uploadZone').classList.add('hidden');
    $('#imageWorkspace').classList.remove('hidden');
    $('#fileName').textContent = loaded.name;
    $('#fileMeta').textContent = `${formatDimensions(loaded.width, loaded.height)} · ${loaded.type.split('/')[1].toUpperCase()} · ${formatBytes(loaded.size)}`;
    $('#originalDimensions').textContent = formatDimensions(loaded.width, loaded.height);
    $('#outputDimensions').textContent = 'Not processed';
    $('#resultResolution').textContent = '—';
    $('#resultSize').textContent = '—';
    $('#resultReady').textContent = 'AWAITING RESULT';
    $('#resultReady').classList.remove('is-ready');
    $('#downloadResult').disabled = true;
    $('#fullPreview').disabled = true;
    $('#controlStatus').textContent = 'IMAGE LOADED';
    $('#controlStatus').style.color = 'var(--accent)';
    updateCompare(50); setZoom(1);
    notify('Image loaded and ready to process.');
  } catch (error) {
    notify(error.message, 'error', 5200);
  }
}

function filePicker() { $('#fileInput').click(); }

async function startProcessing() {
  if (!currentImage) { notify('Upload an image before processing.', 'warning'); return; }
  if (processController) return;
  const mode = $('#processingMode').value;
  if (mode === 'ai' && !modelManager.engineInstance?.provider) {
    notify('The selected AI model is not ready yet. Open Models to check its status.', 'warning', 5000);
    setView('models');
    return;
  }
  const factor = mode === 'enhance' ? 1 : Number($$('.segmented-control [data-factor]').find(button => button.classList.contains('selected'))?.dataset.factor || settings.defaultFactor);
  const resizeMethod = $('#resizeMethod').value;
  processController = new AbortController();
  const signal = processController.signal;
  $('#controlStatus').textContent = 'PROCESSING';
  $('#controlStatus').style.color = 'var(--warning)';
  setBusy(true, mode === 'ai' ? 'Preparing AI inference…' : 'Preparing image processing…');
  if (mode !== 'ai') $('#cancelProcess').classList.add('hidden');
  setProgress(null);
  try {
    const result = await processImage({
      bitmap: currentImage.bitmap,
      mode,
      factor,
      resizeMethod,
      adjustments: adjustmentsFromUI(),
      engine: modelManager.engineInstance,
      signal,
      onProgress: event => setProgress(event.percent, event.message)
    });
    if (signal.aborted) throw new DOMException('Processing cancelled.', 'AbortError');
    resultCanvas = result.canvas;
    const mime = $('#outputFormat').value;
    const quality = Number($('#imageQuality').value) / 100;
    resultBlob = await canvasToBlob(resultCanvas, mime, quality);
    if (resultUrl) URL.revokeObjectURL(resultUrl);
    resultUrl = URL.createObjectURL(resultBlob);
    $('#afterImage').src = resultUrl;
    $('#afterImage').classList.remove('hidden');
    $('#emptyResultHint').classList.add('hidden');
    updateCompare(50);
    $('#outputDimensions').textContent = formatDimensions(result.width, result.height);
    $('#resultResolution').textContent = formatDimensions(result.width, result.height);
    $('#resultSize').textContent = formatBytes(resultBlob.size);
    $('#resultReady').textContent = 'RESULT READY';
    $('#resultReady').classList.add('is-ready');
    $('#downloadResult').disabled = false;
    $('#fullPreview').disabled = false;
    $('#controlStatus').textContent = 'COMPLETED';
    $('#controlStatus').style.color = 'var(--success)';
    $('#processingMessage').textContent = 'Enhancement completed';
    $('#processingState').classList.remove('busy', 'error');
    $('#processingState .state-indicator').style.background = 'var(--success)';
    $('#processButton').disabled = false;
    $('#cancelProcess').classList.add('hidden');
    $('#progressTrack').classList.add('hidden');
    const factorLabel = mode === 'enhance' ? '1×' : `${factor}×`;
    await saveHistoryEntry(result, { mode, factorLabel });
    if (result.reduced) notify(`AI inference used a reduced ${formatDimensions(result.inputWidth, result.inputHeight)} input to stay within the browser memory budget.`, 'warning', 6500);
    else notify('Image enhancement completed successfully.');
  } catch (error) {
    if (error.name === 'AbortError') {
      $('#processingMessage').textContent = 'Processing cancelled';
      $('#processingState').classList.remove('busy');
      $('#processButton').disabled = false;
      $('#cancelProcess').classList.add('hidden');
      $('#progressTrack').classList.add('hidden');
      $('#controlStatus').textContent = 'CANCELLED';
      $('#controlStatus').style.color = 'var(--muted)';
      notify('Processing cancelled.');
    } else {
      setProcessingError(error.message);
      $('#controlStatus').textContent = 'ERROR';
      $('#controlStatus').style.color = 'var(--danger)';
      notify(error.message, 'error', 5500);
    }
  } finally {
    processController = null;
  }
}

function cancelProcessing() {
  if (!processController) return;
  processController.abort();
  modelManager.engineInstance?.cancel();
}

async function saveHistoryEntry(result, { mode, factorLabel }) {
  const modeLabel = mode === 'ai' ? 'AI Upscaling' : mode === 'standard' ? 'Standard resize' : 'Enhancement';
  const record = {
    fileName: currentImage.name,
    modelName: mode === 'ai' ? modelManager.modelConfig.name : '',
    originalDimensions: formatDimensions(currentImage.width, currentImage.height),
    outputDimensions: formatDimensions(result.width, result.height),
    mode,
    modeLabel,
    factorLabel: mode === 'ai' && factorLabel === '2×' ? 'AI 4× → 2×' : factorLabel,
    processLabel: result.processLabel,
    createdAt: Date.now()
  };
  try {
    if (settings.saveHistoryResults) record.resultBlob = resultBlob;
    if (settings.saveHistoryThumbnails) {
      const thumb = document.createElement('canvas');
      const scale = Math.min(1, 180 / Math.max(result.width, result.height));
      thumb.width = Math.max(1, Math.round(result.width * scale)); thumb.height = Math.max(1, Math.round(result.height * scale));
      thumb.getContext('2d').drawImage(result.canvas, 0, 0, thumb.width, thumb.height);
      record.thumbnail = thumb.toDataURL('image/webp', .7);
      thumb.width = 1; thumb.height = 1;
    }
    await addHistory(record);
    await refreshHistory();
  } catch (error) {
    if (settings.saveHistoryResults) notify(`Image processed, but it could not be added to history (${error.message}).`, 'warning', 5000);
  }
}

async function exportCurrentResult() {
  if (!resultCanvas) { notify('There is no processed image to export.', 'warning'); return; }
  try {
    const type = $('#outputFormat').value;
    const quality = Number($('#imageQuality').value) / 100;
    const blob = await canvasToBlob(resultCanvas, type, quality);
    const filename = `${safeFileName(currentImage?.name || 'clarity-result')}-clarity.${mimeExtension(type)}`;
    await downloadBlob(blob, filename);
    notify('Export started. Check your browser downloads.');
  } catch (error) { notify(error.message, 'error'); }
}

async function refreshHistory() {
  try {
    currentHistory = await getHistory();
    renderHistory(currentHistory, openHistoryResult, removeHistoryItem);
  } catch (error) {
    $('#historyList').textContent = `History storage is unavailable: ${error.message}`;
  }
}

async function openHistoryResult(item) {
  if (!item.resultBlob) return;
  try {
    const historyFile = new File([item.resultBlob], item.fileName || 'clarity-result.png', { type: item.resultBlob.type || 'image/png' });
    await acceptImageFile(historyFile);
    const bitmap = await createImageBitmap(item.resultBlob);
    if (currentImage?.bitmap) currentImage.bitmap.close();
    currentImage = { ...currentImage, bitmap, width: bitmap.width, height: bitmap.height, name: item.fileName || 'Saved result', size: item.resultBlob.size };
    resultCanvas = document.createElement('canvas');
    resultCanvas.width = bitmap.width; resultCanvas.height = bitmap.height;
    resultCanvas.getContext('2d').drawImage(bitmap, 0, 0);
    resultBlob = item.resultBlob;
    if (resultUrl) URL.revokeObjectURL(resultUrl);
    resultUrl = URL.createObjectURL(resultBlob);
    $('#afterImage').src = resultUrl;
    $('#afterImage').classList.remove('hidden');
    $('#emptyResultHint').classList.add('hidden');
    $('#outputDimensions').textContent = item.outputDimensions;
    $('#resultResolution').textContent = item.outputDimensions;
    $('#resultSize').textContent = formatBytes(item.resultBlob.size);
    $('#resultReady').textContent = 'SAVED RESULT'; $('#resultReady').classList.add('is-ready');
    $('#downloadResult').disabled = false; $('#fullPreview').disabled = false;
    setView('enhance');
  } catch (error) { notify(error.message, 'error'); }
}

async function removeHistoryItem(id) {
  await deleteHistoryItem(id);
  await refreshHistory();
  notify('History item deleted.');
}

async function refreshStorageUsage() {
  const estimate = await getStorageEstimate();
  $('#storageUsage').textContent = estimate?.usage != null ? `${formatBytes(estimate.usage)} used` : 'Not available';
}

function bindEvents() {
  bindButtonAnimations();
  $$('.nav-link,[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
  $('#themeToggle').addEventListener('click', async () => {
    const theme = document.body.classList.contains('theme-light') ? 'dark' : 'light';
    setTheme(theme); $('#settingTheme').value = theme; await persistSetting('theme', theme);
  });
  $('#settingTheme').addEventListener('change', async event => { setTheme(event.target.value); await persistSetting('theme', event.target.value); });
  $('#reducedMotion').addEventListener('change', async event => { document.body.classList.toggle('reduced-motion', event.target.checked); await persistSetting('reducedMotion', event.target.checked); });

  $('#uploadZone').addEventListener('click', event => { if (!event.target.closest('#browseButton')) filePicker(); });
  $('#uploadZone').addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); filePicker(); } });
  $('#browseButton').addEventListener('click', event => { event.stopPropagation(); filePicker(); });
  $('#replaceImage').addEventListener('click', filePicker);
  $('#fileInput').addEventListener('change', event => { const file = event.target.files?.[0]; if (file) acceptImageFile(file); event.target.value = ''; });
  for (const eventName of ['dragenter', 'dragover']) $('#uploadZone').addEventListener(eventName, event => { event.preventDefault(); $('#uploadZone').classList.add('dragging'); });
  for (const eventName of ['dragleave', 'drop']) $('#uploadZone').addEventListener(eventName, event => { event.preventDefault(); $('#uploadZone').classList.remove('dragging'); });
  $('#uploadZone').addEventListener('drop', event => { const file = event.dataTransfer?.files?.[0]; if (file) acceptImageFile(file); });

  $('#zoomIn').addEventListener('click', () => setZoom(zoom + .15));
  $('#zoomOut').addEventListener('click', () => setZoom(zoom - .15));
  $('#zoomReset').addEventListener('click', () => setZoom(1));
  $('#compareRange').addEventListener('input', event => updateCompare(event.target.value));

  // Let users drag directly on the image, including the divider handle, with a mouse or touch.
  const compareStage = $('#compareStage');
  let activeComparePointer = null;
  compareStage.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    activeComparePointer = event.pointerId;
    compareStage.classList.add('is-comparing');
    try { compareStage.setPointerCapture(event.pointerId); } catch { /* pointer capture is optional */ }
    updateCompareFromPointer(event);
  });
  compareStage.addEventListener('pointermove', event => {
    if (activeComparePointer === event.pointerId) updateCompareFromPointer(event);
  });
  const stopCompareDrag = event => {
    if (activeComparePointer !== event.pointerId) return;
    activeComparePointer = null;
    compareStage.classList.remove('is-comparing');
    try { if (compareStage.hasPointerCapture(event.pointerId)) compareStage.releasePointerCapture(event.pointerId); } catch { /* already released */ }
  };
  compareStage.addEventListener('pointerup', stopCompareDrag);
  compareStage.addEventListener('pointercancel', stopCompareDrag);
  compareStage.addEventListener('lostpointercapture', stopCompareDrag);

  $('#processingMode').addEventListener('change', updateModeControls);
  $('#aiModelSelect').addEventListener('change', event => activateModel(event.target.value));
  $('#modelChoiceGrid').addEventListener('click', event => {
    const choice = event.target.closest('[data-model-select]');
    if (choice) activateModel(choice.dataset.modelSelect);
  });
  $('#factorControl').addEventListener('click', event => {
    const button = event.target.closest('[data-factor]'); if (!button) return;
    selectFactor(button.dataset.factor); persistSetting('defaultFactor', settings.defaultFactor);
  });
  $('#presetSelect').addEventListener('change', event => {
    const values = PRESETS[event.target.value];
    for (const [key, value] of Object.entries(values)) { $(`#${key}`).value = value; $(`#${key}Value`).textContent = value; }
  });
  $('#resetAdjustments').addEventListener('click', () => {
    $('#presetSelect').value = 'natural';
    for (const [key, value] of Object.entries(PRESETS.natural)) { $(`#${key}`).value = value; $(`#${key}Value`).textContent = value; }
  });
  ADJUSTMENT_KEYS.forEach(key => $(`#${key}`).addEventListener('input', event => {
    $(`#${key}Value`).textContent = event.target.value;
    $('#presetSelect').value = 'custom';
  }));
  $('#imageQuality').addEventListener('input', event => $('#qualityValue').textContent = `${event.target.value}%`);
  $('#outputFormat').addEventListener('change', event => $('#qualityControl').classList.toggle('hidden', event.target.value === 'image/png'));
  $('#processButton').addEventListener('click', startProcessing);
  $('#cancelProcess').addEventListener('click', cancelProcessing);
  $('#downloadResult').addEventListener('click', exportCurrentResult);
  $('#downloadFromPreview').addEventListener('click', exportCurrentResult);
  $('#fullPreview').addEventListener('click', () => {
    if (!resultUrl) return;
    $('#fullPreviewImage').src = resultUrl;
    $('#fullPreviewMeta').textContent = `${formatDimensions(resultCanvas.width, resultCanvas.height)} · ${formatBytes(resultBlob.size)}`;
    $('#previewDialog').showModal();
  });
  $('#closePreview').addEventListener('click', () => $('#previewDialog').close());
  $('#previewDialog').addEventListener('click', event => { if (event.target === $('#previewDialog')) $('#previewDialog').close(); });

  $('#downloadModelButton').addEventListener('click', async () => {
    if (modelManager.state.downloading) { modelManager.cancelDownload(); return; }
    const ok = await modelManager.download();
    if (ok) {
      const loaded = await modelManager.load();
      notify(loaded ? `Model downloaded, verified, and loaded · ${modelManager.engineInstance.provider}.` : 'Model downloaded and verified, but the AI engine could not load. See the model error details.', loaded ? 'success' : 'error', 5200);
    } else if (!modelManager.state.downloading && modelManager.state.statusText === 'Download cancelled') notify('Model download cancelled.', 'warning');
  });
  $('#loadModelButton').addEventListener('click', async () => {
    if (modelManager.engineInstance?.provider) { modelManager.unload(); notify('AI model unloaded from memory.'); return; }
    const ok = await modelManager.load();
    if (ok) notify(`AI model loaded · ${modelManager.engineInstance.provider}.`);
    else notify('Could not load the model. See the model error details.', 'error', 5000);
  });
  $('#verifyModelButton').addEventListener('click', async () => {
    const ok = await modelManager.verify();
    notify(ok ? 'Model checksum verified.' : 'Model verification failed. See the model status.', ok ? 'success' : 'error');
  });
  $('#deleteModelButton').addEventListener('click', deleteLocalModel);
  $('#deleteModelFromSettings').addEventListener('click', deleteLocalModel);
  $('#openModelsFromControl').addEventListener('click', () => setView('models'));

  $('#clearHistory').addEventListener('click', async () => {
    if (!confirm('Delete all local processing history? Saved result files in history will also be removed.')) return;
    await clearStoredHistory(); await refreshHistory(); notify('History cleared.');
  });

  $('#defaultMode').addEventListener('change', event => persistSetting('defaultMode', event.target.value));
  $('#defaultFactor').addEventListener('change', event => { persistSetting('defaultFactor', event.target.value); selectFactor(event.target.value); });
  $('#defaultFormat').addEventListener('change', event => persistSetting('defaultFormat', event.target.value));
  $('#defaultQuality').addEventListener('input', event => $('#defaultQualityValue').textContent = `${event.target.value}%`);
  $('#defaultQuality').addEventListener('change', event => persistSetting('defaultQuality', Number(event.target.value)));
  $('#saveHistoryResults').addEventListener('change', event => persistSetting('saveHistoryResults', event.target.checked));
  $('#saveHistoryThumbnails').addEventListener('change', event => persistSetting('saveHistoryThumbnails', event.target.checked));
  $('#refreshStorage').addEventListener('click', refreshStorageUsage);
  $('#resetSettings').addEventListener('click', async () => {
    if (!confirm('Reset all Clarity AI preferences to their defaults? This will not delete your AI model or history.')) return;
    settings = { ...DEFAULT_SETTINGS };
    for (const [key, value] of Object.entries(settings)) await persistSetting(key, value);
    await loadSettings();
    await activateModel(settings.aiModelId, { silent: true });
    notify('Settings restored to defaults.');
  });
}

async function deleteLocalModel() {
  if (!confirm('Delete the verified AI model from this browser? You can download it again later.')) return;
  try { await modelManager.remove(); notify('Local AI model deleted.'); }
  catch (error) { notify(error.message, 'error'); }
}

async function initialize() {
  bindEvents();
  await loadSettings();
  updateProviderAvailability();
  $('#qualityControl').classList.toggle('hidden', $('#outputFormat').value === 'image/png');
  const hash = location.hash.replace('#', '');
  if (['enhance', 'history', 'models', 'settings'].includes(hash)) setView(hash);
  // Auto-prepare only the selected model. Lite is the default to keep the
  // first visit download small; Balanced and Max download only when selected.
  const selectedModelId = MODELS[settings.aiModelId] ? settings.aiModelId : DEFAULT_MODEL_ID;
  const modelStartup = modelManager.selectModel(selectedModelId, { autoDownload: true, autoLoad: true });
  updateModeControls();
  setModelUI({ ...modelManager.state, modelId: modelManager.modelConfig.id, modelMeta: modelManager.modelConfig });
  await refreshHistory();
  await refreshStorageUsage();
  await modelStartup;
}

initialize().catch(error => {
  console.error('Clarity AI initialization failed:', error);
  notify(`Application initialization failed: ${error.message}`, 'error', 8000);
});

window.addEventListener('beforeunload', () => {
  modelManager.engineInstance?.unload();
  if (currentImage?.bitmap) currentImage.bitmap.close();
  if (originalUrl) URL.revokeObjectURL(originalUrl);
  if (resultUrl) URL.revokeObjectURL(resultUrl);
});
