export class AIEngine {
  constructor() {
    this.worker = null;
    this.provider = null;
    this.modelConfig = null;
    this.requestId = 0;
    this.pending = new Map();
    this.activeJob = null;
  }

  async load(modelBuffer, modelConfig = {}) {
    if (typeof Worker === 'undefined') throw new Error('Web Workers are unavailable. This browser cannot safely run the AI worker.');
    this.unload();
    this.modelConfig = modelConfig;
    this.worker = new Worker(new URL('./ai-worker.js', import.meta.url), { type: 'module', name: 'clarity-ai-inference' });
    this.worker.addEventListener('message', event => this.#handleMessage(event.data));
    this.worker.addEventListener('error', event => this.#failAll(new Error(event.message || 'The AI worker stopped unexpectedly.')));
    const id = ++this.requestId;
    const transferable = modelBuffer instanceof ArrayBuffer
      ? modelBuffer.slice(0)
      : modelBuffer.buffer.slice(modelBuffer.byteOffset, modelBuffer.byteOffset + modelBuffer.byteLength);
    const promise = this.#createPending(id, 'ready');
    const workerModelConfig = {
      id: modelConfig.id,
      name: modelConfig.name,
      scale: modelConfig.scale || 4,
      inputName: modelConfig.inputName || 'input',
      outputName: modelConfig.outputName || 'output',
      tileSize: modelConfig.tileSize || 128,
      requiredProvider: modelConfig.requiredProvider || null
    };
    this.worker.postMessage({ type: 'init', requestId: id, buffer: transferable, modelConfig: workerModelConfig }, [transferable]);
    const result = await promise;
    this.provider = result.provider;
    return this.provider;
  }

  async upscale(imageData, width, height, { onProgress = () => {}, signal } = {}) {
    if (!this.worker || !this.provider) throw new Error('Load the selected AI model before processing an image.');
    const jobId = ++this.requestId;
    this.activeJob = jobId;
    const promise = this.#createPending(jobId, 'result', onProgress);
    const abort = () => this.worker?.postMessage({ type: 'cancel', jobId });
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
    const pixels = imageData.data instanceof Uint8ClampedArray ? imageData.data : new Uint8ClampedArray(imageData.data);
    this.worker.postMessage({ type: 'upscale', jobId, width, height, pixels: pixels.buffer, options: {} }, [pixels.buffer]);
    try { return await promise; }
    finally { signal?.removeEventListener('abort', abort); this.activeJob = null; }
  }

  cancel() {
    if (this.activeJob != null) this.worker?.postMessage({ type: 'cancel', jobId: this.activeJob });
  }

  unload() {
    this.worker?.postMessage({ type: 'dispose' });
    this.worker?.terminate();
    this.worker = null;
    this.provider = null;
    this.modelConfig = null;
    this.#failAll(new Error('AI worker was unloaded.'));
  }

  #createPending(id, expectedType, onProgress = () => {}) {
    return new Promise((resolve, reject) => this.pending.set(id, { expectedType, resolve, reject, onProgress }));
  }

  #handleMessage(message) {
    if (message.type === 'progress') {
      this.pending.get(message.jobId)?.onProgress(message);
      return;
    }
    const id = message.requestId ?? message.jobId;
    const pending = this.pending.get(id);
    if (!pending) return;
    if (message.type === 'error') {
      this.pending.delete(id);
      const error = new Error(message.message || 'AI processing failed.');
      error.name = message.name || 'Error';
      pending.reject(error);
    } else if (message.type === 'ready' || message.type === 'result') {
      this.pending.delete(id);
      if (message.type === 'result') message.pixels = new Uint8ClampedArray(message.pixels);
      pending.resolve(message);
    }
  }

  #failAll(error) {
    for (const pending of this.pending.values()) pending.reject(error);
    this.pending.clear();
  }
}
