export function applyEnhancements(sourceCanvas, settings) {
  const output = document.createElement('canvas');
  output.width = sourceCanvas.width; output.height = sourceCanvas.height;
  const ctx = output.getContext('2d', { alpha: false, willReadFrequently: true });
  if (!ctx) throw new Error('Canvas processing is unavailable.');
  const brightness = 100 + Number(settings.brightness || 0);
  const contrast = 100 + Number(settings.contrast || 0);
  const saturation = 100 + Number(settings.saturation || 0);
  const noise = Number(settings.noiseReduction || 0);
  const blur = noise / 100 * 1.05;
  ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)${blur > 0 ? ` blur(${blur.toFixed(2)}px)` : ''}`;
  ctx.drawImage(sourceCanvas, 0, 0);
  ctx.filter = 'none';

  const sharpness = Number(settings.sharpness || 0) / 100;
  if (sharpness > 0.005 && output.width * output.height <= 8000000) {
    const image = ctx.getImageData(0, 0, output.width, output.height);
    const original = image.data;
    const blurredCanvas = document.createElement('canvas');
    blurredCanvas.width = output.width; blurredCanvas.height = output.height;
    const blurredCtx = blurredCanvas.getContext('2d', { willReadFrequently: true });
    blurredCtx.filter = 'blur(1px)'; blurredCtx.drawImage(output, 0, 0);
    blurredCtx.filter = 'none';
    const softened = blurredCtx.getImageData(0, 0, output.width, output.height).data;
    const amount = Math.min(1.35, sharpness * 1.35);
    for (let i = 0; i < original.length; i += 4) {
      original[i] = clamp(original[i] + (original[i] - softened[i]) * amount);
      original[i + 1] = clamp(original[i + 1] + (original[i + 1] - softened[i + 1]) * amount);
      original[i + 2] = clamp(original[i + 2] + (original[i + 2] - softened[i + 2]) * amount);
    }
    ctx.putImageData(image, 0, 0);
    blurredCanvas.width = 1; blurredCanvas.height = 1;
  }
  return output;
}

export function resizeCanvas(source, factor, method = 'bicubic') {
  const target = document.createElement('canvas');
  target.width = Math.max(1, Math.round(source.width * factor));
  target.height = Math.max(1, Math.round(source.height * factor));
  const ctx = target.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('Canvas resizing is unavailable.');
  if (method === 'nearest') {
    ctx.imageSmoothingEnabled = false;
  } else {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = method === 'bilinear' ? 'medium' : 'high';
  }
  ctx.drawImage(source, 0, 0, target.width, target.height);
  return target;
}

function clamp(value) { return Math.max(0, Math.min(255, Math.round(value))); }
