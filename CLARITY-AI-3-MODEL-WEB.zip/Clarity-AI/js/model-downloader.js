export async function downloadVerifiedModel({ model, onProgress = () => {}, signal } = {}) {
  if (!model?.url || !model?.sha256) throw new Error('The selected model is missing its download URL or checksum configuration.');
  if (!globalThis.crypto?.subtle) throw new Error('Secure browser cryptography is unavailable. Open Clarity AI over HTTPS or localhost, then retry.');

  const sources = [model.url, ...(model.fallbackUrls || [])];
  const sourceErrors = [];

  for (let sourceIndex = 0; sourceIndex < sources.length; sourceIndex++) {
    const sourceUrl = sources[sourceIndex];
    try {
      if (signal?.aborted) throw new DOMException('Download cancelled.', 'AbortError');
      onProgress({ preparing: true, sourceIndex, sourceCount: sources.length, sourceUrl });
      const response = await fetch(sourceUrl, {
        method: 'GET', mode: 'cors', credentials: 'omit', cache: 'no-store', signal,
        headers: { Accept: 'application/octet-stream' }
      });
      if (!response.ok) throw new Error(`Model source returned ${response.status} ${response.statusText}.`);

      const totalHeader = response.headers.get('content-length');
      const parsedTotal = totalHeader ? Number(totalHeader) : null;
      const total = Number.isFinite(parsedTotal) && parsedTotal > 0 ? parsedTotal : null;
      let loaded = 0;
      const startedAt = performance.now();
      let preallocated = total ? new Uint8Array(total) : null;
      const chunks = [];

      if (response.body?.getReader) {
        const reader = response.body.getReader();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (signal?.aborted) throw new DOMException('Download cancelled.', 'AbortError');
            if (preallocated && loaded + value.byteLength <= preallocated.byteLength) {
              preallocated.set(value, loaded);
            } else {
              if (preallocated) { chunks.push(preallocated.subarray(0, loaded)); preallocated = null; }
              chunks.push(value);
            }
            loaded += value.byteLength;
            const elapsed = Math.max(1, (performance.now() - startedAt) / 1000);
            const percent = total && total > 0 ? Math.min(100, loaded / total * 100) : null;
            onProgress({ loaded, total, percent, speed: loaded / elapsed, sourceIndex, sourceCount: sources.length, sourceUrl });
          }
        } catch (error) {
          try { await reader.cancel(); } catch { /* no-op */ }
          throw error;
        }
      } else {
        const buffer = await response.arrayBuffer();
        preallocated = new Uint8Array(buffer);
        loaded = buffer.byteLength;
        onProgress({ loaded, total: total || loaded, percent: 100, speed: loaded / Math.max(.001, (performance.now() - startedAt) / 1000), sourceIndex, sourceCount: sources.length, sourceUrl });
      }

      let bytes;
      if (preallocated && loaded === preallocated.byteLength) bytes = preallocated;
      else if (preallocated && chunks.length === 0 && loaded <= preallocated.byteLength) bytes = preallocated.subarray(0, loaded);
      else {
        const totalLoaded = chunks.reduce((sum, chunk) => sum + chunk.byteLength, 0);
        bytes = new Uint8Array(totalLoaded);
        let cursor = 0;
        for (const chunk of chunks) { bytes.set(chunk, cursor); cursor += chunk.byteLength; }
      }

      onProgress({ loaded, total: total || loaded, percent: 100, speed: loaded / Math.max(.001, (performance.now() - startedAt) / 1000), verifying: true, sourceIndex, sourceCount: sources.length, sourceUrl });
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      const hash = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
      if (hash !== model.sha256) {
        bytes.fill(0);
        throw new Error(`Model integrity check failed at ${new URL(sourceUrl).host}. Expected SHA-256 ${model.sha256.slice(0, 12)}… but received ${hash.slice(0, 12)}….`);
      }
      return { bytes, hash, loaded, sourceUrl };
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
      sourceErrors.push(`${new URL(sourceUrl).host}: ${error?.message || error}`);
      if (sourceIndex < sources.length - 1) {
        onProgress({ preparing: true, fallback: true, sourceIndex: sourceIndex + 1, sourceCount: sources.length, detail: 'The primary source was unavailable. Trying the next source with the same SHA-256 requirement.' });
      }
    }
  }
  throw new Error(`Could not download ${model.name} from any configured source. ${sourceErrors.join(' | ')} Check internet access, browser shields/extensions, or try again.`);
}

export async function verifyModelBytes(bytes) {
  const view = bytes instanceof ArrayBuffer ? bytes : bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  const digest = await crypto.subtle.digest('SHA-256', view);
  return [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
}
