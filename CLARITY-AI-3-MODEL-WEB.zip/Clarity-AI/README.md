# CLARITY AI — Professional Image Enhancement Studio

A modular, HTML-first image enhancement studio. The app uses browser-native Canvas APIs for standard resizing and adjustments, and ONNX Runtime Web with three selectable Real-ESRGAN models for actual AI super-resolution.

## Features

- Responsive desktop and mobile workspace with dark/light themes.
- JPG, PNG, and WebP upload with file-size and dimension validation.
- Before/after comparison with direct mouse/touch dragging, a visible slider fallback, zoom, and full-result preview.
- Visible button feedback: hover, press, click pulse, and pointer ripple animations.
- Three AI model tiers: Lite (4.9 MB), Balanced (32.2 MB), and Max (63.9 MB).
- Per-model download, SHA-256 verification, IndexedDB storage, and automatic loading when selected.
- Streaming progress when the browser exposes byte counts, cancellation, SHA-256 verification, and IndexedDB persistence.
- Local model verification at startup and explicit load/unload/delete controls.
- ONNX inference in a Web Worker, with tiled 4× output and an overlapped border around each tile.
- AI 2× output is created by running the true 4× model then downscaling the output.
- Standard nearest-neighbor, bilinear-style medium smoothing, and browser high-quality/bicubic-style resizing (not AI; smoothing quality hints can vary by browser).
- Working brightness, contrast, saturation, sharpness, and noise-reduction controls.
- PNG, JPEG, and WebP export.
- Local metadata history. Saving full result files and thumbnails is opt-in and off by default.
- Settings stored locally, with a localStorage fallback for preferences if IndexedDB is unavailable.

## Run locally

Use a local web server. Do not open `index.html` directly as a `file://` URL; ES modules, Web Crypto, Workers, and persistent browser storage work best on a secure origin.

### Python

```bash
cd Clarity-AI
python -m http.server 8000
```

Then open `http://localhost:8000`.

### Node.js

```bash
npx serve .
```

Open the local URL printed by the server.

## Deploy

The project is static and can be published to Netlify, GitHub Pages, or another static host. Upload the **contents** of this folder so `index.html` is at the site root. HTTPS is recommended and is required by browser secure-context rules for some capabilities outside localhost.

## Automatic model setup

Clarity AI offers three on-device model tiers. Only the selected model is downloaded; the default is Lite so a first-time visitor does not automatically download the largest model.

| Tier | Model | Download | Native output | Device notes |
|---|---|---:|---:|---|
| Lite | Real-ESRGAN General x4v3 FP32 | 4.9 MB | 4× | Smallest model; supports WebGPU or WASM fallback. |
| Balanced | Real-ESRGAN x4plus FP16 | 32.2 MB | 4× | Half-precision weights; requires WebGPU. |
| Max | Real-ESRGAN x4plus FP32 | 63.9 MB | 4× | Full precision; supports compatible WebGPU or fallback providers. |

When the app starts, it checks IndexedDB for the selected model, verifies its SHA-256, and loads it automatically. If it is missing, the selected model is downloaded, verified, saved, and loaded. Selecting a different tier performs the same lifecycle for that model. Other models are not automatically downloaded. The Models page also provides cancel/retry, verify, unload, and delete controls. If persistent storage is unavailable, verified bytes can be used for the current tab only.

The tier names describe network size, numerical precision, and device demand; they are not a promise that every image will look progressively better from Lite to Max. The Lite model uses a smaller general-purpose architecture, while Balanced and Max use x4plus weights at FP16 and FP32 precision. Compare results on your own source images before choosing a default for a public site.

The initial model download and the ONNX Runtime Web package require an internet connection. Runtime JavaScript/WASM assets are loaded from jsDelivr when the model is loaded. On a different origin (for example, `localhost` versus a Netlify URL), browser storage is separate, so the model may need to be downloaded once for that origin.

## Runtime details

- ONNX Runtime Web is pinned to `1.31.1` and the worker imports the provider-specific ES module build from jsDelivr (`ort.webgpu`, `ort.webgl`, or `ort.wasm`).
- The worker tries WebGPU, then WebGL where the worker runtime exposes it, then WASM for models that permit fallback. Balanced FP16 requires WebGPU. Browser/provider support varies; the actual selected provider is shown in the Models screen.
- The worker reads the configured model input/output tensor names and feeds float32 NCHW RGB data. All three registry models use a 4× output graph. The Balanced FP16 model is restricted to WebGPU; the Lite and Max variants can use the configured fallback providers.
- Inference is tiled to lower peak input memory. Each tile uses a 16-pixel input border, and only the tile's center area is copied into the final 4× image.
- To limit browser memory use, AI input is automatically reduced when it exceeds 450,000 pixels or a 1,280-pixel longest side. Standard output is capped at 8 million pixels. The workspace reports this reduction after processing. For large source photographs, this means the final result is 4× the bounded inference input, not necessarily 4× the original file dimensions.
- A browser that does not provide a compatible ONNX execution provider, sufficient GPU/CPU memory, or the required cross-origin access may fail to load/run the model. The UI reports the actual error; it does not create a fake result.
- WebGL is attempted from the dedicated worker when OffscreenCanvas exists. Some browser builds do not expose the WebGL provider in workers; in that case the app continues to WASM.
- Canvas standard resizing offers nearest, bilinear, and the browser's high-quality interpolation. A separate Lanczos implementation is not included, so the UI does not label its browser interpolation as Lanczos.

## Privacy and storage

- Image files are decoded and processed locally in the browser. There is no image-upload endpoint in this project.
- The ONNX model and runtime assets are downloaded from their documented external sources.
- History metadata is stored locally. Full result blobs and thumbnails are not persisted unless the corresponding Settings switches are enabled.
- Clearing history removes saved result blobs and thumbnails. Deleting the model removes the stored ONNX bytes from IndexedDB.

## Project structure

```text
Clarity-AI/
├── index.html
├── css/
│   ├── style.css
│   ├── animations.css
│   └── responsive.css
├── js/
│   ├── app.js
│   ├── config.js
│   ├── ui.js
│   ├── storage.js
│   ├── image-loader.js
│   ├── image-processor.js
│   ├── enhancement.js
│   ├── export.js
│   ├── model-downloader.js
│   ├── model-manager.js
│   ├── ai-engine.js
│   └── ai-worker.js
├── models/README.md
└── assets/icons/clarity-mark.svg
```

## Validation status

The JavaScript source is syntax-checked and internal file references are checked in the delivered project. A full browser/device test, a live 63.9 MB download, the SHA-256 check against a fresh download, and end-to-end ONNX inference could not be run in this build environment. Complete those checks in a real HTTPS/localhost browser before treating the deployment as production-ready.
