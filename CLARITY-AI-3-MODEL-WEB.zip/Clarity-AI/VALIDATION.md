# Validation report

## Checks completed in this build environment

- All 12 JavaScript ES modules passed Node syntax checks.
- The three-model registry check passed: each entry has a unique matching ID, HTTPS source URL, 64-character SHA-256 digest, tensor names, and native 4× output metadata.
- All 121 HTML IDs are unique; required model selector and card IDs exist; all local HTML asset references resolve.
- Static inspection confirms app startup selects the saved model (Lite by default), checks IndexedDB, verifies its SHA-256, downloads it if missing or invalid, persists it when possible, and loads ONNX Runtime automatically.
- Changing the selected tier routes through the same model manager and uses that model's own source, checksum, tensor names, precision/provider requirement, and tile settings.
- A mocked downloader test passed: primary-source failure falls back to the configured mirror, and the resulting bytes are accepted only when the SHA-256 matches.
- A second mocked downloader test passed: a checksum mismatch is rejected.
- A local Python HTTP server successfully served `index.html`, `js/config.js`, and `js/model-manager.js`; the served content matched the local files.
- The comparison pointer interaction and button feedback animation code remain present from the previous revision.

## Checks not completed

- No full interactive browser/device test was completed in this build environment.
- No live model download from Hugging Face or a mirror was completed here.
- No real ONNX Runtime session initialization or end-to-end image inference was completed here.
- Balanced requires WebGPU; actual compatibility and memory headroom depend on the visitor's browser, GPU driver, and device.

Before public release, test all three tiers on the target browsers and devices over HTTPS. In particular, test first-time model download, reload from IndexedDB, model switching, cancellation, and actual image inference. The model files are intentionally not bundled in this ZIP; visitors download only the tier they select.
