# Panduan CLARITY AI (3 pilihan model)

## Menjalankan di Windows

1. Ekstrak ZIP proyek.
2. Buka folder `Clarity-AI`.
3. Klik address bar File Explorer, ketik `cmd`, lalu tekan Enter.
4. Jalankan:

```cmd
py -m http.server 8000
```

5. Buka `http://localhost:8000` di Chrome, Edge, atau Brave.
6. Jangan tutup jendela CMD selama aplikasi digunakan.

## Tiga model AI

Clarity AI menyediakan tiga tingkat model. Aplikasi hanya mengunduh model yang dipilih, bukan ketiganya sekaligus.

| Pilihan | Model | Ukuran unduhan | Cocok untuk |
|---|---|---:|---|
| Lite | Real-ESRGAN General x4v3 FP32 | sekitar 4,9 MB | HP dan komputer biasa, foto harian, screenshot, gambar JPEG. |
| Balanced | Real-ESRGAN x4plus FP16 | sekitar 32,2 MB | Perangkat yang memiliki WebGPU; bobot FP16 dengan ukuran lebih kecil dari Max. |
| Max | Real-ESRGAN x4plus FP32 | sekitar 63,9 MB | Komputer lebih kuat dan restorasi detail dengan bobot FP32 penuh. |

Ketiga model menghasilkan gambar native 4×. Opsi 2× di aplikasi dibuat dengan menjalankan model 4× lalu mengecilkan hasilnya secara berkualitas tinggi.

**Model Lite dipilih secara default** agar pengunduhan pertama tetap kecil. Untuk menggantinya, pilih model pada dropdown `AI MODEL` di workspace atau buka menu `Models`, lalu klik kartu model yang diinginkan. Model terpilih akan otomatis diperiksa, diunduh bila belum ada, diverifikasi SHA-256, disimpan di browser, dan dimuat ke ONNX Runtime.

Balanced memerlukan WebGPU. Bila browser tidak menyediakan WebGPU, pilih Lite atau Max.

**Catatan kualitas:** tingkatan Lite/Balanced/Max menunjukkan ukuran jaringan, presisi, dan kebutuhan perangkat; bukan jaminan bahwa hasil setiap foto akan selalu meningkat secara berurutan. Lite memakai arsitektur General x4v3 yang lebih kecil, sedangkan Balanced dan Max memakai bobot x4plus dengan presisi FP16 dan FP32. Coba ketiganya pada foto yang sama untuk menentukan pilihan terbaik bagi pengunjung website.

## Penyimpanan dan privasi

- Model disimpan di IndexedDB browser pada domain yang sama.
- Model yang sudah tersimpan tidak perlu diunduh ulang kecuali data situs dihapus atau checksum tidak cocok.
- Hanya satu model aktif dimuat ke memori pada satu waktu. Model lain yang pernah diunduh tetap tersimpan di browser.
- Foto dan hasil proses AI tetap berada di perangkat; model/runtime diunduh dari internet.
- Saat alamat berubah (misalnya dari `localhost` ke Netlify), penyimpanan browser berbeda, sehingga model dapat perlu diunduh sekali lagi di domain tersebut.

## Publikasi ke web

Proyek ini bersifat statis dan dapat diunggah ke Netlify atau GitHub Pages. Pastikan `index.html` berada di root folder publik. Gunakan HTTPS. Model dan runtime tetap diunduh oleh browser dari sumber yang dicantumkan di `js/config.js`.

## Catatan kompatibilitas

- ONNX Runtime Web dan file runtime WASM/JS dimuat dari CDN, jadi koneksi internet tetap dibutuhkan saat runtime belum tercache.
- Kecepatan bergantung pada perangkat, browser, WebGPU, dan ukuran gambar.
- Input AI dapat diperkecil otomatis untuk menjaga penggunaan memori browser.
- Ukuran 4× tidak berarti detail asli yang hilang pasti dapat dipulihkan; hasil merupakan perkiraan AI.
